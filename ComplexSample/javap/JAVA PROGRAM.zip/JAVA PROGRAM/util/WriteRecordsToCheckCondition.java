import java.io.*;
import java.util.logging.*;

public class WriteRecordsToCheckCondition{
	public static void main(String[] args) throws IOException{
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter file name which has '.log' extesion: ");
		String str = bf.readLine();
		File file = new File(str + ".log");
		if(file.exists()){
			FileHandler hand = new FileHandler(str + ".log", true);
			Logger log = Logger.getLogger("");
			System.out.println("Enter level of a logger: ");
			String str1 = bf.readLine();
			String level = str1.toUpperCase();
			if(level.equals("INFO")){
				LogRecord rec1 = new LogRecord(Level.INFO, "Welcome to RoseIndia.Net");
				hand.publish(rec1);
				System.out.println("Operation completly successfully!");
			}
			else if(level.equals("WARNING")){
				LogRecord rec2 = new LogRecord(Level.WARNING,"Do something here!");
				hand.publish(rec2);
				System.out.println("Operation completly successfully!");
			}
			else if(level.equals("SEVERE")){
				LogRecord rec3 = new LogRecord(Level.SEVERE, "Provide java program");
				hand.publish(rec3);
				System.out.println("Operation completly successfully!");
			}
			else{
				System.out.println("Invalid Level entry!");
			}
			log.addHandler(hand);
			
			}
		else{
			System.out.println("File is not found");
		}
	}
}