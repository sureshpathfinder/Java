import java.util.*;
class ran
{
public static void main(String args[])
{
int i;
int a[]=new int[10];
Random r1=new Random();
TreeSet t1=new TreeSet();
System.out.println("\n BEFORE TESTING \n");
for(i=0;i<10;i++)
{
a[i]=r1.nextInt();
System.out.println(a[i]);
}
System.out.println("\n AFTER TESTING \n");
for(i=0;i<10;i++)
{
String s="\n"+Integer.toString(a[i]);
t1.add(s);
}
System.out.println(t1);
}
}
