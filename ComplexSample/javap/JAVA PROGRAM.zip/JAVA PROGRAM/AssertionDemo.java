class AssertionDemo
{
	public static void main(String args[])
	{
		System.out.println(withDraw(1000,500));
System.out.println(withDraw(1000,5000));
	}
	public static int withDraw(int b,int c)
	{
		assert b>=c;
		return b-c;
	}
}