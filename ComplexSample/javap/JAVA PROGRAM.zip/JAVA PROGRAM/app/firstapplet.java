import java.awt.*;
import java.applet.*;

public class firstapplet extends Applet
{
	public void paint(Graphics g)
	{
		g.drawString("WELCOME TO APPLET",150,50);
	}
	
}
//<applet code="firstapplet.class" width=350 height=500></applet>