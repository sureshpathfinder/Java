public class q3{ 
public static void main(String argv[])
{ 
System.out.println(argv[2]) ;
}
}
