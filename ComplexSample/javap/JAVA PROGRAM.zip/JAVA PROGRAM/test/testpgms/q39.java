public class q39 { 
                static String st; 
                public static void main(String str[]){ 
                        System.out.print(st+"yes"); 
                } 
        } 
