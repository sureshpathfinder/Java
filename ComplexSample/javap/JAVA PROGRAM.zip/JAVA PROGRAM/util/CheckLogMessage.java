import java.io.*;
import java.util.logging.*;

public class CheckLogMessage{
	public static void main(String[] args) {
		Logger log = Logger.getLogger("log_file");
		if(log.isLoggable(Level.OFF)){
			log.finest("Display a finest message");
		}
	}
}
