package pack1;
public class one
{
        public void show()
        {
                System.out.println("Inside class one");
        }
}
