public class ADirtyOne
{
public static void main(String args[])
{
System.out.println(Math.abs(Integer.MIN_VALUE));
System.out.println(Math.min(0.0,-0.0));
System.out.println(Math.round(Float.MAX_VALUE));
}
}
