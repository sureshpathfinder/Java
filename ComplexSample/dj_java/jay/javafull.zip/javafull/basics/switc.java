class switc
{
        public static void main(String ar[])
        {
                char a;
                a='p';
                switch(a)
                {
                        case 'a':
                                System.out.println("Is A Vowel");
                                break;
                        case 'e':
                                System.out.println("Is A Vowel");
                                break;
                        case 'i':
                                System.out.println("Is A Vowel");
                                break;
                        case 'o':
                                System.out.println("Is A Vowel");
                                break;
                        case 'u':
                                System.out.println("Is A Vowel");
                                break;
                        default:
                                System.out.println("Is not a vowel");
                    }


         }
}

