class for1
{
        public static void main(String ar[])
        {
                long i,fact=1,f=19;
                for(i=1;i<=f;i++)
                {
                        fact=fact*i;
                }
                System.out.println("Factorial of " +f +" = "+fact);
        }
}

