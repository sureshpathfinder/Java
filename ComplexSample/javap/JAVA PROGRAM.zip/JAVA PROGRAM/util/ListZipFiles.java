import java.util.*;
import java.util.zip.*;
import java.io.*;

public class ListZipFiles{
	public static void main(String[] args) throws IOException{
		ListZipFiles zf = new ListZipFiles();
	}

	public ListZipFiles() throws IOException{
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Enter Zip file name: ");
		String filename = in.readLine();
		if(!filename.endsWith(".zip")){
			System.out.println("Invalid file name!");
			System.exit(0);
		}
		else if(!new File(filename).exists()){
			System.out.println("File not exist!");
			System.exit(0);
		}

		try{
			ZipFile zipFile = new ZipFile(filename);
			Enumeration em = zipFile.entries();
			for (Enumeration em1 = zipFile.entries(); em1.hasMoreElements();){
				System.out.println(em1.nextElement());
			}
		}
		catch(ZipException ze){
			System.out.println(ze.getMessage());
			System.out.println("Zip file may be corrupted.");
			System.exit(0);
		}
	}
} 
