class array1
{
        public static void main(String ar[])
        {
                int d;
                int a[]={1,2,3,4,5};
                System.out.println("a[0] = "+a[0]+ "\na[1] = "+a[1]+ "\na[2] = "+a[2]+ "\na[3] = "+a[3]+ "\na[4] = "+a[4]);
                d=3;
                System.out.println("We Going to print "+d+" Position");
                d=d-1;
                System.out.println("a["+d+"] = "+a[d]);

        }
}




