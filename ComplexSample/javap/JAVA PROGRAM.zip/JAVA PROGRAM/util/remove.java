import java.util.*;

public class remove{
		public static void main (String args[]){
			ArrayList arr = new ArrayList();
			System.out.println("Total elements of iterator: ");
			for (int i = 1; i < 10; i++) arr.add(i);
			int count = 0;
			for (Iterator i = arr.iterator(); i.hasNext();){
					System.out.println ("element is " + i.next());
					}
					System.out.println("After removing : ");
			for (Iterator i = arr.iterator(); i.hasNext();){
				count++;
				i.next();
				if (count%4 == 0) i.remove();
				}
				for (Iterator i = arr.iterator(); i.hasNext();){
					System.out.println ("element is " + i.next());
					}
					}
	}