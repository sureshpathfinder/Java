public class NEE extends Exception
{
	public String message()
	{
	System.out.println("1");	
	return "Balance Should not be Less than 100";
		
	}
}