class arith
{
        public static void main(String ar[])
        {
                int a,b,add,sub,mul,div,mod;
                a=5;
                b=3;
                add=a+b;
                sub=a-b;
                mul=a*b;
                div=a/b;
                mod=a%b;
                System.out.println("A Value is "+a);
                System.out.println("B Value is "+b);
                System.out.println("Addition = "+add);
                System.out.println("Subraction = "+sub);
                System.out.println("Multiplication = "+mul);
                System.out.println("Division = "+div);
                System.out.println("Modulus = "+mod);
        }
}


