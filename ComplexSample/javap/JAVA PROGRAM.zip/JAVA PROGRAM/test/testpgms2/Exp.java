public class Exp
{
private final int i =10;
private byte k = i;

	public static void main(String args[])
	{
		byte b=0;
		b+=1455;
		System.out.println(b);
		char c =(char)-146;
		System.out.println(c);
//		System.out.println(k);

	}
}