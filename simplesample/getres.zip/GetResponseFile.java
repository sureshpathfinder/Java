package com.action;

import java.io.*;
import java.util.*;
import com.util.FileReaders;

public class GetResponseFile
{
	   String response = null;



public static String readFile(String temp)
{
	try{

	 File f= new File(new  FileReaders().getResLoc() + "//" +temp);
	 InputStream fw  = new FileInputStream(f);
	 int c;
	 String s1 = "";
	 while ((c = fw.read()) != -1) {
	  s1 = s1 + (char)c;
     }
	 return s1;
	}catch(Exception e)
	{
	  e.printStackTrace();
	  return null;
	}
}


public String getResponseFiles(String mesid,String folder)
{

		String user= System.getProperty("user.dir");
		 int st1 = user.lastIndexOf(92);
		System.out.println("((())))))" + st1);
		System.out.println("((())))))" + user.substring(0,st1));
		System.out.println("files to be searched in this folder" + folder);
		String s=user.substring(0,st1) + "/bin/test.bat " + folder + " " + mesid;
		String s3;
				System.out.println("Executable File location " + s);
		try{
				Process p = Runtime.getRuntime().exec(s);
				System.out.println("Bat file executed to get the response file");
				InputStream in = p.getInputStream();
				int c;
				String s1 = "";
				while ((c = in.read()) != -1) {
				    s1 = s1 + (char)c;

				}
				in.close();
				System.out.println("s1++++++++=" + s1);
				 String s2[] =null;int count=0;
				 StringTokenizer st = new StringTokenizer(s1,"\n");
				 s2 = new String[st.countTokens()];
				 while(st.hasMoreTokens())
				 {
					s2[count]=st.nextToken();
					if((s2[count].indexOf(": 1")) > 0)
					{
						if(s2[count].startsWith("--"))
						{
							s3 = s2[count];
							System.out.println(s3.substring(11,39));
							response = readFile(s3.substring(11,39));
							System.out.println(response);
							break;
						}
					}
					count++;
				 }
					return response;


			}catch(Exception e)
			{
				System.out.println("Exception throen GetResponsefile class )))))))))))))))))))))");
			e.printStackTrace();
			return null;
			}

}



}