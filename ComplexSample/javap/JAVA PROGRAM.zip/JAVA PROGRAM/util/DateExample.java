import java.util.*;

class DateExample 
{
	public static void main(String[] args) 
	{
		Date d=new Date();
		int y=1900+d.getYear();
		int z=1+d.getMonth();
		System.out.println("Date is "+d.getDate()+"/"+z+"/"+y);
	}
}
