import pack1.*;
import pack1.pack2.two;
class three
{
        public static void main(String ar[])
        {
                one o=new one();
                o.show();
                two t=new two();
                t.kar();
        }
}



