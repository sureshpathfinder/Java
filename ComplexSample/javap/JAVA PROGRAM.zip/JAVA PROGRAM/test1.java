package hai;
import java.lang.*;
public class test1
{
public void hello()
{
	System.out.println("Hai");
}
public static void main(String args[])
{
	test1 t=new test1();
	t.hello();
}
}