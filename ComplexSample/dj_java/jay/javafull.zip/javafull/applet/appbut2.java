import java.awt.*;
import java.applet.*;
import java.awt.event.*;
public class appbut2 extends JFrame implements ActionListener
{
        JButton b1;
        appbut2()
        {
                setSize(400,400);
                setVisible(true);
                setTitle("Hai Demo Frame");
                b1= new JButton("Click Here");
                b1.addActionListener(this);
        }
        public void actionPerformed(ActionEvent e)
        {
                Runtime r
        }
}


