public class q4 { 
        public static void main(String argv[]){ 
                int anar[]=new int[]{1,2,3};
                System.out.println(anar[1]); 
                } 
}

