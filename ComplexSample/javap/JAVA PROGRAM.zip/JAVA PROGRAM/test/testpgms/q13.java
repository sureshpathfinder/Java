public class q13
{
public static void main(String ar[])
{
	boolean b=true;
	boolean b1=true;
	if(b==b1)
		System.out.println("1");
int i=1; 
int j=2; 
if(i==1|| j==2) 
        System.out.println("OK");
int k=0;
if(k)
{       System.out.println("OK");}

}}