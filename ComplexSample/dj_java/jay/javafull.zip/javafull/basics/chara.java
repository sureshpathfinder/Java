class chara
{
        public static void main(String ar[])
        {
                char x='a';
                System.out.println("At First x="+x);
                x++;
                System.out.println("Now x="+x);
         }
}

                
