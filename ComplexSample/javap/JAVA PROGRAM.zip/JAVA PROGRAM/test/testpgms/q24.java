class q24{ 
public static void main(String ar[])
{
	   
  int i=0; 
        while(true){ 
                i++; 
                System.out.println("i="+i); 
            } //End while 

}}