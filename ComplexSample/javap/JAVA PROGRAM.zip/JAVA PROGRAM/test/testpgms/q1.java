public class q1
{
public static void main(String a[])
{
 float f=1.3; 
 char c="a"; 
 byte b=257; 
 boolean w=null; 
 int i=10;
}
}