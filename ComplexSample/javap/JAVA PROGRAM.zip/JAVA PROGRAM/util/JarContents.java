import java.util.*;
import java.util.jar.*;
import java.util.zip.*;
import java.io.*;

public class JarContents{
	public static void main(String[] args) throws IOException{
		JarContents mc = new JarContents();
	}
	
	public JarContents() throws IOException{
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Enter jar file name: ");
		String filename = in.readLine();
		File file = new File(filename);
		if(!filename.endsWith(".jar")){
			System.out.println("Invalid file name!");
			System.exit(0);
		}
		else if(!file.exists()){
			System.out.println("File not exist!");
			System.exit(0);
		}
		
		try{
			JarFile jarfile = new JarFile(filename);
			Enumeration em = jarfile.entries();
			for (Enumeration em1 = jarfile.entries(); em1.hasMoreElements();) {
				System.out.println(em1.nextElement());
			}
		}
		catch(ZipException ze){
			System.out.println(ze.getMessage());
			System.exit(0);
		}
	}
}
