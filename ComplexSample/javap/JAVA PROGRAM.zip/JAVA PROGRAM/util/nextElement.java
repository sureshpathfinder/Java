import java.util.Enumeration; 
import java.util.Vector; 
import java.util.*;

 public class nextElement{  
	   public static void main (String[] args){ 
		   
		   Vector strVector = new Vector(); 
		   String str = new String();
		   strVector.addElement(new String("Hi")); 
		   strVector.addElement(new String("Hello")); 
		   strVector.addElement(new String("Namaste")); 
		   strVector.addElement(new String("Salam")); 
		   strVector.addElement("Salam"); 
		   
		   Enumeration elements = strVector.elements(); 
		   while (elements.hasMoreElements()){  
			   str = (String)elements.nextElement(); 
			   System.out.println(str); 
			   }  
			   }  
	 }  