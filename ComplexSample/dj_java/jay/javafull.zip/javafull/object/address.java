  public interface address  //strore the interface in address.java
   {
                        public void add(String addr);
                        public void name(String nam);
      }
