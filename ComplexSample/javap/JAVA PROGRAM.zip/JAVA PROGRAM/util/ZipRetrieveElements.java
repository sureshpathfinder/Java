import java.util.*;
import java.util.zip.*;
import java.io.*;

public class ZipRetrieveElements{
	public static void main(String[] args){
		ZipRetrieveElements zr = new ZipRetrieveElements();
	}

	public ZipRetrieveElements() {
		OutputStream out = null;
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.print("Eneter zip file name to unzip: ");
			String sourcefile = bf.readLine();
			if(!sourcefile.endsWith(".zip")){
				System.out.println("Invalid file name!");
				System.exit(0);
			}
			else if(!new File(sourcefile).exists()){
				System.out.println("File not exist!");
				System.exit(0);
			}

			ZipInputStream in = new ZipInputStream(new FileInputStream(sourcefile));
			ZipFile zf = new ZipFile(sourcefile);
			int a = 0;
			for(Enumeration em = zf.entries(); em.hasMoreElements();){
				String targetfile = em.nextElement().toString();
				ZipEntry ze = in.getNextEntry();
				out = new FileOutputStream(targetfile);
				byte[] buf = new byte[1024];
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
				a = a + 1;
			}
			if(a > 0) System.out.println("Files unzipped.");
			out.close();
			in.close();
		} catch (IOException e) {
			System.out.println("Error: Operation failed!");
			System.exit(0);
		}
	}
}
