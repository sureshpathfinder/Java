import java.sql.*;
import java.io.*;

class DbInsert
{
	public static void main(String args[])
	{
		try
		{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	Connection c = DriverManager.getConnection("jdbc:odbc:swing","","");
	PreparedStatement ps = c.prepareStatement("insert into stud values (?,?)");
BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
System.out.println("Enter Roll NO");
	String s1=br.readLine();
	int rollno = Integer.parseInt(s1);
System.out.println("Enter Name");
	String name=br.readLine();
	ps.setInt(1,rollno);
	ps.setString(2,name);
	boolean b=ps.execute();
	if(!b)
	System.out.println("inserted");
	else
	System.out.println("Not inserted");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}

