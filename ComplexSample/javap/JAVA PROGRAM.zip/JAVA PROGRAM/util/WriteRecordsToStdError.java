import java.util.logging.*;

public class WriteRecordsToStdError{
	public static void main(String[] args) {
		WriteRecordsToStdError r = new WriteRecordsToStdError();
	}
	public WriteRecordsToStdError(){
		ConsoleHandler err = new ConsoleHandler();
		Logger log = Logger.getLogger("");
		LogRecord rec1 = new LogRecord(Level.WARNING,"Do something here!");
		LogRecord rec2 = new LogRecord(Level.INFO,"Do something here!");
		LogRecord rec3 = new LogRecord(Level.SEVERE,"Do something here!");
		err.publish(rec1);
		err.publish(rec2);
		err.publish(rec3);
		log.addHandler(err);
		System.out.println(log.addHandler(err));
	}
}
