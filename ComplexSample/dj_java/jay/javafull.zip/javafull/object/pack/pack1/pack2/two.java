package pack1.pack2;
public class two
{
        public void kar()
        {
                System.out.println("'Inside class two");
        }

}
