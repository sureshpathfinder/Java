class nestif
{
        public static void main(String ar[])
        {
                int a,b,c;
                a=17;
                b=15;
                c=8;
                if(a>b)
                {
                        if(a>c)
                        {
                                System.out.println(a+" is Greatest");
                        }
                        else
                        {
                                System.out.println(c+" is Greatest");
                        }
                 }
                 else
                 {
                        if(b>c)
                        {
                                System.out.println(b+" is Greatest");
                        }
                        else
                        {
                                System.out.println(c+" is Greatest");
                        }
                 }

                                
            }
}
