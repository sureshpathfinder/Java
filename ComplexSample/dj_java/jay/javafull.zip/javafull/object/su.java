/*Final:-
        if a variable is declared as final the value cannot be changed.
        if a mehod is declared as final then it cannot be overridden.
        if a class is declared as final then it cannot be extended.
*/

class su
{
        public static void main(String ar[])
        {
       final int i=0;
       i=i+1;
        System.out.println(i);
        }
}
