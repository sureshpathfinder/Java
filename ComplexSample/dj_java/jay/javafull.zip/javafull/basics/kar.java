class kar
{
        public static void main(String ar[])
        {
                System.out.println("Welcome to Java Programming");
        }
}


