public class q11
{
public static void main(String ar[])
{
	int i=9; 
        switch (i) 
		{ 
                	case 0: 
	                System.out.println("zero"); 
        		break; 
		        case 1: 
                	System.out.println("one"); 
 		        case 2: 
 	               System.out.println("two"); 
        		default: 
	                System.out.println("default"); 	
        	}
}
}