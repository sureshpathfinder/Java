import java.io.*;
import java.util.*;

public class AssociateValue{
	public static void main(String[] args) throws IOException{
		try{
			String str;
			IdentityHashMap<Integer,String> map = new IdentityHashMap<Integer,String>();
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			System.out.print("Enter the hash code for the first object: ");
			int a = Integer.parseInt(in.readLine());
			System.out.print("Enter the text value for this code: ");
			map.put(new Integer(a), in.readLine());
			System.out.print("Enter the hash code for the second object: ");
			int b = Integer.parseInt(in.readLine());
			System.out.print("Enter the text value for this code: ");
			map.put(new Integer(b), in.readLine());
			System.out.print("Enter the hash code for the third object: ");
			int c = Integer.parseInt(in.readLine());
			System.out.print("Enter the text value for this code: ");
			map.put(new Integer(c), in.readLine());
			System.out.print("Enter the hash code for the fourth object: ");
			int d = Integer.parseInt(in.readLine());
			System.out.print("Enter the text value for this code: ");
			map.put(new Integer(d), in.readLine());
			System.out.println(map);
			Set set = map.entrySet();
			Iterator it = set.iterator();
			while(it.hasNext()){
				Map.Entry me = (Map.Entry)it.next();
				System.out.print(me.getKey() + ": ");
				System.out.println(me.getValue());
			}
		}
		catch(NumberFormatException ne){
			System.out.println(ne.getMessage() + " is not a legal value.");
			System.exit(0);
		}
	}
}