import java.awt.*;
import javax.swing.*;
/*<applet code=label width=250 height=150>
</applet>*/
public class label extends JApplet
{
        JLabel l1,l2;
        public void init()
        {
                Container cp=getContentPane();
                cp.setLayout(new FlowLayout());
                ImageIcon ind=new ImageIcon("India.gif");
                l1=new JLabel("India",ind,JLabel.CENTER);
                l2=new JLabel("Karthik");
                cp.add(l1);
                cp.add(l2);
        }
}


