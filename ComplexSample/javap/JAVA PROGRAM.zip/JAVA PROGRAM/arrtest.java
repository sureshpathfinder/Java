class arrtest
{
public static void main(String arg[])
{
	int a[]={1,2,3,4,5};
	System.out.println(a.length);
}
}