public class q2 { 
        public static void main(String arguments[]) { 
                amethod(arguments); 
                } 
        public static void amethod(String[] arguments) { 
                System.out.println(arguments); 
                System.out.println(arguments[1]); 
        } 
}
