package org.apache.jsp;

import java.sql.*;
import java.util.*;
import javax.naming.*;
import javax.sql.*;

public class DBHandle extends HttpServe
{

	Connection conn = null;
	Statement st = null;
	ResultSet rs = null;
	DataSource ds = null;
	String strDriverName = null;
	String strUrl= null;
	String strHost = null;
	String strPort = null;
	String strDatabase = null;
	String strUser = null;
	String strPass = null;
	String site=null;
	String sitePath=null;

	int intInitConnection= 0;
	int intMaxConnection = 0;

	public Connection getConnection_cp()
	{
		try
		{
			//Hashtable env = new Hashtable();
			//env.put(Context.INITIAL_CONTEXT_FACTORY,"org.apache.commons.dbcp.BasicDataSourceFactory");
			//env.put(Context.PROVIDER_URL,"localhost:8080");
			//Properties parms = new Properties();
			//parms.put(Context.INITIAL_CONTEXT_FACTORY, "org.apache.commons.dbcp.BasicDataSourceFactory");

			System.out.println("@Getting Properties IN Connection pool@@@");
			Context initContext = new InitialContext();
			Context envContext  = (Context)initContext.lookup("java:comp/env");
			DataSource ds = (DataSource)envContext.lookup("jdbc/TestDB");
			conn = ds.getConnection();

		System.out.println("Connected");
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}finally{
			System.out.println("Inside finally");
		return conn;
	}
	}

	public void closeConnection(Connection con)
	{
		try
		{
			if(con!=null)
				con.close();
			System.out.println("****Successfully Disconnected****");

		}
		catch(Exception ex)
		{

			System.out.println(ex.getMessage());
		}
	}

public static void main(String args[])
{
	DBHandle obj = new DBHandle();
	Connection connect=	obj.getConnection_cp();
	}


}