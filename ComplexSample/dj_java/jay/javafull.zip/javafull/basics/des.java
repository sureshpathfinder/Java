class des
{
int a=10;
}
class des1 extends des
{
public static void main(String k[])
{
des1 f=new des1();
System.out.println(f.a);
}
}
