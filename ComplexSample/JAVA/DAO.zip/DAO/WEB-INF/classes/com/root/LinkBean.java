package com.root;
public class LinkBean {
protected String title = null;
protected String url = null;
protected String desc = null;

public String getTitle() { return title; }
public void setTitle(String title) { this.title = title; }
public String getUrl() { return url; }
public void setUrl(String url) { this.url = url; }
public String getDescription() { return desc; }
public void setDescription(String desc) { this.desc =desc;}
}