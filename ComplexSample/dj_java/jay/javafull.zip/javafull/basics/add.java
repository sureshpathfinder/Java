                                /* Addition of 2 numbers */
class add
{
        public static void main(String ar[])
        {
                int a,b,c;
                a=5;
                b=6;
                c=a+b;
                System.out.println("Addition of "+a+" and "+b+" is "+c);
         }
}
