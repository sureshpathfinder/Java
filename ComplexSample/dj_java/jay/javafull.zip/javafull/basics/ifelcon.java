class ifelcon
{
        public static void main(String ar[])
        {
                int num;
                num=9;
                if(num%2==0)
                {
                        System.out.println("Even Number");
                }
                else
                {
                        System.out.println("Odd Number");
                }
         }
}
