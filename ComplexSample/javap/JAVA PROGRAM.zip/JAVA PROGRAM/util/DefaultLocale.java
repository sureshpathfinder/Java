import java.util.*;

public class DefaultLocale{
	public static void main(String[] args){
		Locale locale = Locale.getDefault();
		System.out.println(locale.getDisplayName() + locale.getCountry());
		Locale.setDefault(Locale.ENGLISH);
		locale = Locale.getDefault();
		System.out.println("For Default Locale : " + locale.getLanguage());
	}
}


