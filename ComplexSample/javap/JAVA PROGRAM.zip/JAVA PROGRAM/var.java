class s
{
public static void main(String ar[])
{
  int a=6;
  System.out.print("welcomegjhghjgjhg="+a);
}
}