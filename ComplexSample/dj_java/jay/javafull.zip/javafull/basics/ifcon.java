                        //Simple If Condition
class ifcon
{
        public static void main(String ar[])
        {
                int a,b,big;
                a=15;
                b=6;
                big=a;
                if(b>big)
                {
                        big=b;
                }
                        System.out.println("Biggest Number = "+big);
         }
}

