import java.util.*;

public class next{
	  public static void main (String args[]) {
		String elements[] = {"Blue", "Grey", "Teal"};
		Set s = new HashSet(Arrays.asList(elements));
		Iterator i = s.iterator();
		while (i.hasNext()) {
		  System.out.println(i.next());
		}
	  }
	}