import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class cook1 extends HttpServlet
{

}	
