class exp1
{
        public static void main(String ar[])
        {
                int i[]={2};
                i[10]=20;
        }
}
